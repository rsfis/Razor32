local user_login_bg = Sprite("/sys/img/user_login_bg.png", 480, 320)

local wallpaper_image = Sprite("/home/images/wallpapers/wallpaper.png", 480, 320)

local desktop_page_image = Sprite("/sys/img/desktop_page.png", 480, 320)

local mouse_cursor_image = Sprite("/sys/icons/mouse_cursor.png", 20, 20)

local gothambold_font = Font("/sys/fonts/Gotham Bold.bin")
local loggedIn = false

local entered_password = ""

-- FPS
local fps = 0
local frameCount = 0
local lastTime = os.clock()

-- ============================================================
--  UI: cores, geometria e opções pré-montadas
--  (as tabelas de opções são criadas uma vez só, pra não gerar lixo a cada frame)
-- ============================================================
local TEXT_Y_BIAS = 1.50       -- sobe/desce TODOS os textos do Wi-Fi: aumente pra subir, diminua pra descer (passos de 0.05)
-- Ajuste fino por elemento, em pixels (negativo = sobe, positivo = desce)
local DEBUG_TEXT_CAL = false -- CALIBRAÇÃO: com o dialog de senha aberto, a rodinha do mouse sobe/desce todos os textos ao vivo
local OFF_LIST = 0         -- nomes das redes na lista
local OFF_BTN  = 0         -- "Cancel" / "Connect"
local OFF_CHK  = 0         -- texto "Show password"
local OFF_PASS = 0         -- senha visível (Show password ligado)
local SCROLL_DIRECTION = 1     -- troque pra -1 se a rodinha do mouse rolar ao contrário

local C = {
   bg     = {28, 28, 30},
   dialog = {36, 36, 40},
   border = {72, 72, 78},
   text   = {255, 255, 255},
   sub    = {150, 150, 158},
   accent = {10, 132, 255},
   green  = {48, 209, 88},
   red    = {255, 99, 88},
   hover  = {52, 52, 58},
   field  = {18, 18, 20},
   btn    = {58, 58, 64},
   off    = {90, 90, 96},
}

local O_POPUP     = { fill = C.bg, border = C.border, borderWidth = 1, radius = 10 }
local O_DIALOG    = { fill = C.dialog, border = {110, 110, 118}, borderWidth = 1, radius = 10 }
local O_SEP       = { fill = C.border }
local O_HOVER     = { fill = C.hover, radius = 6 }
local O_SW_ON     = { fill = C.green, radius = 11 }
local O_SW_OFF    = { fill = C.off, radius = 11 }
local O_KNOB      = { fill = C.text }
local O_THUMB     = { fill = C.sub, radius = 1 }
local O_FIELD     = { fill = C.field, border = C.accent, borderWidth = 2, radius = 6 }
local O_DOT       = { fill = C.text }
local O_DOT_G     = { fill = C.green }
local O_CURSOR    = { fill = C.text }
local O_BTN       = { fill = C.btn, radius = 6 }
local O_BTN_HOVER = { fill = {76, 76, 82}, radius = 6 }
local O_BTN_PRI   = { fill = C.accent, radius = 6 }
local O_BTN_PRI_H = { fill = {52, 154, 255}, radius = 6 }
local O_CHK_OFF   = { fill = C.field, border = C.sub, borderWidth = 1, radius = 3 }
local O_CHK_ON    = { fill = C.accent, radius = 3 }
local O_TICK_W    = { closed = false, border = C.text, borderWidth = 2, join = "round" }
local O_TICK_G    = { closed = false, border = C.green, borderWidth = 2, join = "round" }
local O_SPIN      = { color = C.accent, thickness = 4, roundCaps = true, track = C.field }

-- Ícone de Wi-Fi na barra superior (área clicável)
local WIFI_ICON = { x = 424, y = 0, w = 26, h = 25 }

-- Ícone de Bluetooth na barra superior (área clicável) e popup
local BT_ICON = { x = 451, y = 0, w = 24, h = 25 }
local BTP = { x = 282, y = 28, w = 190, h = 52 }
local BT_SW = { x = BTP.x + BTP.w - 16 - 42, y = BTP.y + 15, w = 42, h = 22 }

-- Popup do Wi-Fi
local POP = { x = 242, y = 28, w = 230, h = 212 }
local SW  = { x = POP.x + POP.w - 16 - 42, y = POP.y + 15, w = 42, h = 22 }
local LIST = { x = POP.x + 8, y = POP.y + 54, w = POP.w - 16, rowH = 30, rows = 5 }
LIST.rowW = LIST.w - 8     -- sobra uma faixa pra barra de rolagem

-- Dialog de senha
local DLG = { w = 210, h = 146, y = 64 }
DLG.x = (480 - DLG.w) // 2
local FIELD = { x = DLG.x + 16, y = DLG.y + 50, w = DLG.w - 32, h = 26 }
local CHK = { x = DLG.x + 16, y = DLG.y + 86, s = 14 }
local BTN_CONNECT = { x = DLG.x + DLG.w - 16 - 74, y = DLG.y + 108, w = 74, h = 26 }
local BTN_CANCEL  = { x = DLG.x + DLG.w - 16 - 74 - 8 - 66, y = DLG.y + 108, w = 66, h = 26 }

-- ============================================================
--  UI: helpers
-- ============================================================
local function textWidth(str, pts)
   return gothambold_font:getTextWidth(str, pts)
end

-- cy = linha central do texto
local function drawText(str, x, cy, pts, c, dy)
   gothambold_font:drawString(str, x, math.floor(cy - pts * TEXT_Y_BIAS + (dy or 0)), pts, c[1], c[2], c[3])
end

local function drawTextCentered(str, cx, cy, pts, c)
   drawText(str, cx - textWidth(str, pts) // 2, cy, pts, c)
end

-- Corta o texto (com "...") pra caber em maxW
local function fitText(str, pts, maxW)
   if textWidth(str, pts) <= maxW then return str end
   local s = str
   while #s > 1 and textWidth(s .. "...", pts) > maxW do
      s = s:sub(1, -2)
   end
   return s .. "..."
end

-- Mantém o FINAL do texto (campo de senha visível)
local function fitTail(str, pts, maxW)
   while #str > 0 and textWidth(str, pts) > maxW do
      str = str:sub(2)
   end
   return str
end

local function inside(px, py, x, y, w, h)
   return px >= x and px < x + w and py >= y and py < y + h
end

local W_CONNECTING = textWidth("Connecting...", 12)
local W_CANCEL     = textWidth("Cancel", 13)
local W_CONNECT    = textWidth("Connect", 13)

local function drawButton(b, label, labelW, primary, hover)
   local opts
   if primary then
      opts = hover and O_BTN_PRI_H or O_BTN_PRI
   else
      opts = hover and O_BTN_HOVER or O_BTN
   end
   Display_DrawRect(b.x, b.y, b.w, b.h, opts)
   drawText(label, b.x + (b.w - labelW) // 2, b.y + b.h // 2, 13, C.text, OFF_BTN)
end

-- ============================================================
--  Wi-Fi: estado e lógica
-- ============================================================
local wifi = {
  open = false,
  nets = {},
  connectedSSID = nil,
  scanning = false,
  status = "off",          -- valor inicial
  scroll = 0,
  lastRefresh = -10,
  searchingUntil = 0,
}

local bt = { open = false, name = nil, label = nil, h = BTP.h }   -- popup do Bluetooth

local function refreshBluetooth()
   local n = OS_IsBluetoothEnabled() and OS_GetConnectedBluetoothName() or nil
   if n ~= bt.name then
      bt.name = n
      bt.label = n and fitText(n, 14, BTP.w - 50) or nil
   end
   bt.h = n and 84 or BTP.h
end
local dlg = nil            -- nil = fechado | { ssid, label, text, show, state, error, startedAt }
local prevMouse1 = false

local function makeNetEntry(ssid)
   return { ssid = ssid, label = fitText(ssid, 14, LIST.rowW - 10 - 34) }
end

-- Mantém a ordem das redes que já estavam na lista (não fica pulando quando o sinal oscila)
local function mergeNetworks(found)
   local present, seen, merged = {}, {}, {}
   for i = 1, #found do present[found[i]] = true end

   for i = 1, #wifi.nets do
      local e = wifi.nets[i]
      if present[e.ssid] then
         merged[#merged + 1] = e
         seen[e.ssid] = true
      end
   end

   for i = 1, #found do
      local s = found[i]
      if not seen[s] then
         merged[#merged + 1] = makeNetEntry(s)
         seen[s] = true
      end
   end

   wifi.nets = merged
end

local function refreshWifi(force)
  local now = os.clock()
  if not force and now - wifi.lastRefresh < 1 then return end
  wifi.lastRefresh = now

  wifi.scanning      = OS_IsWifiScanning()
  wifi.connectedSSID = OS_GetConnectedWifiSSID()   -- pode ser nil
  wifi.status        = OS_GetWifiStatus()           -- ← ADICIONE ISTO

  if not OS_IsWifiEnabled() then
    wifi.nets = {}
    wifi.scroll = 0
    return
  end

  mergeNetworks(OS_GetFoundWifiNetworks())

  local maxScroll = math.max(0, #wifi.nets - LIST.rows)
  if wifi.scroll > maxScroll then wifi.scroll = maxScroll end
end

local function toggleWifi()
   if OS_IsWifiEnabled() then
      OS_DisableWifi()
   else
      OS_EnableWifi()
      wifi.searchingUntil = os.clock() + 4
   end
   wifi.nets = {}
   wifi.scroll = 0
   wifi.connectedSSID = nil
   wifi.lastRefresh = -10
end

-- ----- Dialog de senha -----
local function openDialog(entry)
   dlg = {
      ssid = entry.ssid,
      label = fitText(entry.ssid, 14, DLG.w - 32),
      text = "",
      show = false,
      state = "input",       -- "input" | "connecting"
      error = nil,
      startedAt = 0,
   }
end

local function submitDialog()
   if dlg == nil or dlg.state ~= "input" then return end
   OS_ConnectWifi(dlg.ssid, dlg.text)   -- o firmware salva ssid/senha e sincroniza a hora se conectar
   dlg.state = "connecting"
   dlg.error = nil
   dlg.startedAt = os.clock()
end

local function updateDialog(key)
   if dlg.state == "connecting" then
      local st = wifi.status
      if st == "connected" and OS_GetConnectedWifiSSID() == dlg.ssid then
         dlg = nil
         refreshWifi(true)
         return
      elseif st == "failed" then
         dlg.state = "input"
         dlg.error = "Couldn't connect. Check the password."
      elseif st == "off" then
         dlg = nil
         return
      elseif os.clock() - dlg.startedAt > 40 then
         dlg.state = "input"
         dlg.error = "Connection timed out."
      end
      if key == "ESC" then dlg = nil end
      return
   end

   if key == nil then return end

   if key == "ESC" then
      dlg = nil
   elseif key == "ENTER" then
      submitDialog()
   elseif key == "RETURN" then
      dlg.text = dlg.text:sub(1, -2)
      dlg.error = nil
   elseif key == "SPACE" then
      if #dlg.text < 63 then dlg.text = dlg.text .. " " end
      dlg.error = nil
   elseif #key == 1 then
      if #dlg.text < 63 then dlg.text = dlg.text .. key end
      dlg.error = nil
   end
   -- FUNCTION/fun/CAPSLOCK/HOME/F1..F9 são ignoradas
end

local function handleDialogClick(mx, my)
   if dlg.state ~= "input" then return end

   if inside(mx, my, CHK.x - 2, CHK.y - 4, 120, CHK.s + 8) then
      dlg.show = not dlg.show
   elseif inside(mx, my, BTN_CONNECT.x, BTN_CONNECT.y, BTN_CONNECT.w, BTN_CONNECT.h) then
      submitDialog()
   elseif inside(mx, my, BTN_CANCEL.x, BTN_CANCEL.y, BTN_CANCEL.w, BTN_CANCEL.h) then
      dlg = nil
   end
end

-- ----- Cliques -----
local function handleClick(mx, my)
   if dlg then
      handleDialogClick(mx, my)      -- o dialog é modal
      return
   end

   -- ícone de Bluetooth: abre/fecha o popup
   if inside(mx, my, BT_ICON.x, BT_ICON.y, BT_ICON.w, BT_ICON.h) then
      bt.open = not bt.open
      wifi.open = false
      return
   end

   -- popup do Bluetooth aberto
   if bt.open then
      if inside(mx, my, BT_SW.x - 6, BT_SW.y - 4, BT_SW.w + 12, BT_SW.h + 8) then
         if OS_IsBluetoothEnabled() then OS_DisableBluetooth() else OS_EnableBluetooth() end
      elseif not inside(mx, my, BTP.x, BTP.y, BTP.w, bt.h) then
         bt.open = false    -- clique fora fecha
      end
      return
   end

   -- ícone de Wi-Fi: abre/fecha o popup
   if inside(mx, my, WIFI_ICON.x, WIFI_ICON.y, WIFI_ICON.w, WIFI_ICON.h) then
      wifi.open = not wifi.open
      if wifi.open then
         wifi.scroll = 0
         wifi.searchingUntil = os.clock() + 4
         refreshWifi(true)
      end
      return
   end

   if not wifi.open then return end

   -- clique fora do popup fecha
   if not inside(mx, my, POP.x, POP.y, POP.w, POP.h) then
      wifi.open = false
      return
   end

   -- botão ligar/desligar
   if inside(mx, my, SW.x - 6, SW.y - 4, SW.w + 12, SW.h + 8) then
      toggleWifi()
      return
   end

   -- lista de redes
   if OS_IsWifiEnabled() and inside(mx, my, LIST.x, LIST.y, LIST.rowW, LIST.rows * LIST.rowH) then
      local row = (my - LIST.y) // LIST.rowH + 1
      local entry = wifi.nets[wifi.scroll + row]
      if entry then
         if entry.ssid == wifi.connectedSSID then
            -- clicou na rede conectada: desconecta e esquece
            OS_ForgetWifi()
            wifi.connectedSSID = nil
            wifi.searchingUntil = os.clock() + 4
            wifi.lastRefresh = -10
         else
            openDialog(entry)
         end
      end
   end
end

-- ============================================================
--  Wi-Fi: desenho
-- ============================================================
local function drawWifiPopup(mx, my, hoverEnabled)
   Display_DrawRect(POP.x, POP.y, POP.w, POP.h, O_POPUP)

   -- título + botão ligar/desligar
   drawText("Wi-Fi", POP.x + 16, POP.y + 26, 17, C.text)

   local on = OS_IsWifiEnabled()
   Display_DrawRect(SW.x, SW.y, SW.w, SW.h, on and O_SW_ON or O_SW_OFF)
   local knobX = on and (SW.x + SW.w - 11) or (SW.x + 11)
   Display_DrawElipse(knobX, SW.y + 11, 9, 9, O_KNOB)

   Display_DrawRect(POP.x + 10, POP.y + 46, POP.w - 20, 1, O_SEP)

   local midX = LIST.x + LIST.rowW // 2
   local midY = LIST.y + 40

   if not on then
      drawTextCentered("Wi-Fi is off", midX, midY, 14, C.sub)
      return
   end

   local count = #wifi.nets
   if count == 0 then
      if wifi.scanning or os.clock() < wifi.searchingUntil then
         drawTextCentered("Searching networks...", midX, midY, 13, C.sub)
      else
         drawTextCentered("No networks found", midX, midY, 13, C.sub)
      end
      return
   end

   -- linhas visíveis
   for i = 1, LIST.rows do
      local entry = wifi.nets[wifi.scroll + i]
      if entry == nil then break end

      local ry = LIST.y + (i - 1) * LIST.rowH

      if hoverEnabled and inside(mx, my, LIST.x, ry, LIST.rowW, LIST.rowH) then
         Display_DrawRect(LIST.x, ry + 1, LIST.rowW, LIST.rowH - 2, O_HOVER)
      end

      drawText(entry.label, LIST.x + 10, ry + LIST.rowH // 2, 14, C.text, OFF_LIST)

      if entry.ssid == wifi.connectedSSID then
         local tx = LIST.x + LIST.rowW - 24
         local ty = ry + 10
         Display_DrawPoligon({tx, ty + 5, tx + 4, ty + 9, tx + 12, ty}, O_TICK_G)
      end
   end

   -- barra de rolagem
   if count > LIST.rows then
      local trackH = LIST.rows * LIST.rowH
      local thumbH = math.max(16, trackH * LIST.rows // count)
      local maxScroll = count - LIST.rows
      local thumbY = LIST.y + (trackH - thumbH) * wifi.scroll // maxScroll
      Display_DrawRect(LIST.x + LIST.w - 4, thumbY, 3, thumbH, O_THUMB)
   end
end

local function drawBluetoothPopup()
   Display_DrawRect(BTP.x, BTP.y, BTP.w, bt.h, O_POPUP)
   drawText("Bluetooth", BTP.x + 16, BTP.y + 26, 17, C.text)

   local on = OS_IsBluetoothEnabled()
   Display_DrawRect(BT_SW.x, BT_SW.y, BT_SW.w, BT_SW.h, on and O_SW_ON or O_SW_OFF)
   local knobX = on and (BT_SW.x + BT_SW.w - 11) or (BT_SW.x + 11)
   Display_DrawElipse(knobX, BT_SW.y + 11, 9, 9, O_KNOB)

   -- dispositivo conectado
   if bt.label then
      Display_DrawRect(BTP.x + 10, BTP.y + 46, BTP.w - 20, 1, O_SEP)
      Display_DrawElipse(BTP.x + 22, BTP.y + 66, 4, 4, O_DOT_G)
      drawText(bt.label, BTP.x + 34, BTP.y + 66, 14, C.text, OFF_LIST)
   end
end

local function drawDialog(mx, my)
   Display_DrawRect(DLG.x, DLG.y, DLG.w, DLG.h, O_DIALOG)
   drawText(dlg.label, DLG.x + 16, DLG.y + 22, 14, C.text)

   if dlg.state == "connecting" then
      local angle = (os.clock() * 360) % 360
      Display_DrawArc(DLG.x + DLG.w // 2, DLG.y + 82, 16, angle, angle + 270, O_SPIN)
      drawText("Connecting...", DLG.x + (DLG.w - W_CONNECTING) // 2, DLG.y + 121, 12, C.sub)
      return
   end

   -- subtítulo / erro
   if dlg.error then
      drawText(fitText(dlg.error, 11, DLG.w - 32), DLG.x + 16, DLG.y + 38, 11, C.red)
   else
      drawText("Enter the network password", DLG.x + 16, DLG.y + 38, 11, C.sub)
   end

   -- campo de senha
   Display_DrawRect(FIELD.x, FIELD.y, FIELD.w, FIELD.h, O_FIELD)
   local midY = FIELD.y + FIELD.h // 2
   local endX

   if dlg.show then
      local shown = fitTail(dlg.text, 14, FIELD.w - 22)
      drawText(shown, FIELD.x + 8, midY, 14, C.text, OFF_PASS)
      endX = FIELD.x + 8 + textWidth(shown, 14)
   else
      local maxDots = (FIELD.w - 22) // 10
      local dots = math.min(#dlg.text, maxDots)
      for k = 0, dots - 1 do
         Display_DrawElipse(FIELD.x + 12 + k * 10, midY, 3, 3, O_DOT)
      end
      endX = FIELD.x + 8 + dots * 10
   end

   -- cursor piscando
   if math.floor(os.clock() * 2) % 2 == 0 then
      Display_DrawRect(endX + 2, FIELD.y + 6, 1, FIELD.h - 12, O_CURSOR)
   end

   -- "Show password"
   Display_DrawRect(CHK.x, CHK.y, CHK.s, CHK.s, dlg.show and O_CHK_ON or O_CHK_OFF)
   if dlg.show then
      Display_DrawPoligon({CHK.x + 3, CHK.y + 7, CHK.x + 6, CHK.y + 10, CHK.x + 11, CHK.y + 4}, O_TICK_W)
   end
   drawText("Show password", CHK.x + 22, CHK.y + 7, 12, C.sub, OFF_CHK)

   -- botões
   drawButton(BTN_CANCEL, "Cancel", W_CANCEL, false,
              inside(mx, my, BTN_CANCEL.x, BTN_CANCEL.y, BTN_CANCEL.w, BTN_CANCEL.h))
   drawButton(BTN_CONNECT, "Connect", W_CONNECT, true,
              inside(mx, my, BTN_CONNECT.x, BTN_CONNECT.y, BTN_CONNECT.w, BTN_CONNECT.h))
end

-- ============================================================
--  Loop principal
-- ============================================================
function loop()
   while true do
      local currentTime = os.clock()
      frameCount = frameCount + 1

      -- Atualiza FPS a cada 1 segundo
      if currentTime - lastTime >= 1 then
         collectgarbage("collect")
         fps = frameCount
         frameCount = 0
         lastTime = currentTime
         --print("FPS:", fps)
         --print("Temperature: ", OS_GetCPUTemperature())
         --print("Free Memory: ", OS_GetFreeHeapMemory())
         --print("Memory Size: ", OS_GetMemorySize())
         --print("RTC: ", OS_GetTime():toString("%d/%m/%Y - %H:%M:%S"))
         --print("Lua Heap Memory Usage: ", OS_GetLuaVMHeapMemoryUsage())
      end

      Display_ClearScreen()
      
      OS_SetKeyboardDelay(150)

      if loggedIn == false then
         user_login_bg:draw(0, 0)
         gothambold_font:drawString(OS_GetUserUsername(), 148, 150, 20, 255, 255, 255)
         gothambold_font:drawString(entered_password, 148, 183, 18, 255, 255, 255)
         gothambold_font:drawString(OS_GetTime():toString("%H:%M"), 185, -10, 40, 255, 255, 255)
         gothambold_font:drawString(OS_GetTime():toString("%d/%m/%Y"), 190, 50, 15, 255, 255, 255)

         local key = OS_GetPressedKey() -- UMA chamada por frame

         if key ~= nil then
            if key == "RETURN" then
               entered_password = entered_password:sub(1, -2)
            elseif key == "ENTER" then
               if entered_password == OS_GetUserPassword() then
                  loggedIn = true
                  entered_password = ""
               end
            elseif key == "SPACE" then
               entered_password = entered_password .. " "
            elseif #key == 1 then
               entered_password = entered_password .. key
            end
            -- FUNCTION/fun/SHIFT/HOME/ESC/F1..F9 são ignoradas
         end
      else
         wallpaper_image:draw(0, 0)
         desktop_page_image:draw(0, 0)
         gothambold_font:drawString(OS_GetTime():toString("%H:%M"), 393, 265, 25, 255, 255, 255)
         gothambold_font:drawString(OS_GetTime():toString("%d/%m"), 335, 280, 16, 255, 255, 255)

         -- ----- entrada (uma leitura de cada por frame) -----
         local connected = OS_HasMouseConnected()
         local mx, my = -1, -1
         if connected then
            local pos = OS_GetMousePosition()
            mx, my = pos[1], pos[2]
         end

         local mouse1 = connected and OS_IsMouse1Pressed()
         local clicked = mouse1 and not prevMouse1       -- só o instante em que o botão é apertado
         prevMouse1 = mouse1

         local scrollDelta = OS_GetMouseScrollDelta()    -- sempre lê: zera o acumulado
         local key = OS_GetPressedKey()
         wifi.status = OS_GetWifiStatus()                -- (também grava no SD a rede nova, quando conecta)

         -- ----- lógica -----
         if dlg then
            updateDialog(key)
         elseif key == "ESC" and (wifi.open or bt.open) then
            wifi.open = false
            bt.open = false
         end

         if bt.open then refreshBluetooth() end

         if clicked then
            handleClick(mx, my)
         end

         if DEBUG_TEXT_CAL and dlg and scrollDelta ~= 0 then
            TEXT_Y_BIAS = TEXT_Y_BIAS - scrollDelta * SCROLL_DIRECTION * 0.05
            scrollDelta = 0
         end

         if wifi.open and dlg == nil and scrollDelta ~= 0 then
            local maxScroll = math.max(0, #wifi.nets - LIST.rows)
            wifi.scroll = math.max(0, math.min(maxScroll, wifi.scroll - scrollDelta * SCROLL_DIRECTION))
         end

         if wifi.open then
            refreshWifi(false)
         end

         -- ----- desenho -----
         if wifi.open then
            drawWifiPopup(mx, my, dlg == nil)
         end

         if bt.open then
            refreshBluetooth()
            drawBluetoothPopup()
         end

         if dlg then
            drawDialog(mx, my)
         end

         if DEBUG_TEXT_CAL then
            gothambold_font:drawString("BIAS " .. string.format("%.2f", TEXT_Y_BIAS), 8, 290, 12, 255, 255, 0)
         end

         -- cursor por cima de tudo
         if connected then
            mouse_cursor_image:draw(mx, my)
         end
      end

      Display_UpdateScreen()
   end
end

function start()
   loop()
end

start()
endProgram()
