local user_login_bg = Sprite("/sys/img/user_login_bg.png", 480, 320)

local wallpaper_image = Sprite("/home/images/wallpapers/wallpaper.png", 480, 320)

local desktop_page_image = Sprite("/sys/img/desktop_page.png", 480, 320)

local mouse_cursor_image = Sprite("/sys/icons/mouse_cursor.png", 20, 20)

local gothambold_font = Font("/sys/fonts/Gotham Bold.bin")
local loggedIn = false

local entered_password = ""

-- FPS
local fps = 0
local frameCount = 0
local lastTime = os.clock()

function loop()
   while true do
      local currentTime = os.clock()
      frameCount = frameCount + 1

      -- Atualiza FPS a cada 1 segundo
      if currentTime - lastTime >= 1 then
         collectgarbage("collect")
         fps = frameCount
         frameCount = 0
         lastTime = currentTime
         --print("FPS:", fps)
         --print("Temperature: ", OS_GetCPUTemperature())
         --print("Free Memory: ", OS_GetFreeHeapMemory())
         --print("Memory Size: ", OS_GetMemorySize())
         --print("RTC: ", OS_GetTime():toString("%d/%m/%Y - %H:%M:%S"))
         --print("Lua Heap Memory Usage: ", OS_GetLuaVMHeapMemoryUsage())
      end

      Display_ClearScreen()
      
      OS_SetKeyboardDelay(150)

      if loggedIn == false then
         user_login_bg:draw(0, 0)
         gothambold_font:drawString(OS_GetUserUsername(), 148, 150, 20, 255, 255, 255)
         gothambold_font:drawString(entered_password, 148, 183, 18, 255, 255, 255)
         gothambold_font:drawString(OS_GetTime():toString("%H:%M"), 185, -10, 40, 255, 255, 255)
         gothambold_font:drawString(OS_GetTime():toString("%d/%m/%Y"), 190, 50, 15, 255, 255, 255)

         local key = OS_GetPressedKey() -- UMA chamada por frame

         if key ~= nil then
            if key == "RETURN" then
               entered_password = entered_password:sub(1, -2)
            elseif key == "ENTER" then
               if entered_password == OS_GetUserPassword() then
                  loggedIn = true
                  entered_password = ""
               end
            elseif key == "SPACE" then
               entered_password = entered_password .. " "
            elseif #key == 1 then
               entered_password = entered_password .. key
            end
            -- FUNCTION/fun/SHIFT/HOME/ESC/F1..F9 são ignoradas
         end
      else
         wallpaper_image:draw(0, 0)
         desktop_page_image:draw(0, 0)
         gothambold_font:drawString(OS_GetTime():toString("%H:%M"), 393, 265, 25, 255, 255, 255)
         gothambold_font:drawString(OS_GetTime():toString("%d/%m"), 335, 280, 16, 255, 255, 255)

         local connected = OS_HasMouseConnected()
         local pos = OS_GetMousePosition()
         local mx, my = pos[1], pos[2]

         if connected then
            mouse_cursor_image:draw(mx, my)
         end
      end

      Display_UpdateScreen()
   end
end

function start()
   loop()
end

start()
endProgram()